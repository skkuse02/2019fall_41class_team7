$(function(){
    var pro_img1 = document.getElementById('pro_img1');
    var pro_img2 = document.getElementById('pro_img2');
    var pro_img3 = document.getElementById('pro_img3');
    var pro_img4 = document.getElementById('pro_img4');
    var pro_img5 = document.getElementById('pro_img5');

    var pro_img = [pro_img1,pro_img2,pro_img3,pro_img4,pro_img5];

    var user_name = "test2";
    var product_list;
    var database = firebase.database().ref().child('Product');
    database.once('value').then( function(data){
      product_list =  Object.keys(data.val());
      var i = 0;
      data.forEach(function(sec_data){

        if(user_name==sec_data.val()['user'])
        {
          if(i<5)
          {
              pro_img[i].src = sec_data.val()['image'][0];

              i++;
          }
        }
      });

    });
    //  }














})();
